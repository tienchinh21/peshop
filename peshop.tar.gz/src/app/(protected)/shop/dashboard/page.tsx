import { Metadata } from "next";
import ShopDashboardView from "@/views/pages/shop/dashboard/ShopDashboardPage";

export const metadata: Metadata = {
  title: "Dashboard - Quản lý Shop | PeShop",
  description: "Quản lý sản phẩm, đơn hàng và doanh thu của cửa hàng",
  keywords: ["quản lý shop", "dashboard", "bán hàng", "PeShop"],
};

/**
 * Shop Dashboard Page (Protected)
 * Server component - handles metadata and renders client view
 */
export default function ShopDashboardPage() {
  return <ShopDashboardView />;
}
