import OrderManager from "@/views/pages/shop/orders/OrderManager";

export default function ShopOrdersPage() {
  return <OrderManager title="Tất cả đơn hàng" />;
}
