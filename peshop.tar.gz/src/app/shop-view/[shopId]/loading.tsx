import { ShopSkeleton } from "@/components/skeleton";

export default function Loading() {
  return <ShopSkeleton />;
}
