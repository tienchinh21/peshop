export {
  axiosDotnet,
  axiosJava,
  axiosDotnetFormData,
  axiosJavaFormData,
} from "@/services/core/http";

export { axiosDotnet as default } from "@/services/core/http";
