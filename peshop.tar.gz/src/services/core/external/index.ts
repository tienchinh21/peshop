export {
  getProvinces,
  getDistrictsByProvince,
  getWardsByDistrict,
} from "./goship-address.service";

